<?php
define("TASKS_FILE", "tasks.json");

// ✅ Load Tasks
function loadTasks(): array {
    if (!file_exists(TASKS_FILE)) {
        return [];
    }

    $data = file_get_contents(TASKS_FILE);
    return $data ? json_decode($data, true) : [];
}

// ✅ Save Tasks
function saveTasks(array $tasks): void {
    $json = json_encode($tasks, JSON_PRETTY_PRINT);
    file_put_contents(TASKS_FILE, $json);
}

$tasks = loadTasks();

// ✅ Add Task
if (isset($_POST['add'])) {
    $taskText = trim($_POST['task']);

    if ($taskText !== "") {
        $tasks[] = [
            "task" => $taskText,
            "done" => false
        ];
        saveTasks($tasks);
    }
    header("Location: index.php");
    exit;
}

// ✅ Delete Task
if (isset($_GET['delete'])) {
    $index = $_GET['delete'];
    unset($tasks[$index]);
    $tasks = array_values($tasks);
    saveTasks($tasks);
    header("Location: index.php");
    exit;
}

// ✅ Toggle Task Done/Undone
if (isset($_GET['toggle'])) {
    $index = $_GET['toggle'];
    $tasks[$index]['done'] = !$tasks[$index]['done'];
    saveTasks($tasks);
    header("Location: index.php");
    exit;
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Simple ToDo App</title>

<style>
    body {
        font-family: Arial, sans-serif;
        width: 450px;
        margin: 40px auto;
    }
    h2 {
        text-align: center;
    }
    .task {
        display: flex;
        justify-content: space-between;
        padding: 8px;
        margin: 5px 0;
        background: #f2f2f2;
        border-radius: 5px;
    }
    .done {
        text-decoration: line-through;
        color: gray;
    }
    .btn {
        padding: 4px 10px;
        margin-left: 5px;
        cursor: pointer;
        border: none;
        border-radius: 3px;
    }
    .delete {
        background: red;
        color: #fff;
    }
    .toggle {
        background: green;
        color: #fff;
    }
</style>

</head>
<body>

<h2>✅ My To-Do List</h2>

<form method="POST">
    <input type="text" name="task" placeholder="Enter task..." required>
    <button name="add">Add</button>
</form>

<hr>

<?php foreach ($tasks as $index => $task): ?>
    <div class="task">
        <span class="<?= $task['done'] ? 'done' : '' ?>">
            <?= htmlspecialchars($task['task']) ?>
        </span>

        <div>
            <a class="btn toggle" href="?toggle=<?= $index ?>">
                <?= $task['done'] ? 'Undo' : 'Done' ?>
            </a>

            <a class="btn delete" href="?delete=<?= $index ?>">Delete</a>
        </div>
    </div>
<?php endforeach; ?>

</body>
</html>
